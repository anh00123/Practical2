import java.io.*;
import java.util.*;
import java.io.PrintWriter;



/**
 * 
 * CSCU9T4 Java strings and files exercise.
 *
 */
public class FilesInOut {

    public static void main(String[] args) throws Exception {
        // Replace this with statements to set the file name (input) and file name (output).
        FileReader reader = new FileReader("C:\\Users\\halle\\Desktop\\CSCUT4Practical2-main\\CSCUT4Practical2-main\\inputm.txt"); // reads the text file using the inserted path
        PrintWriter writer = new PrintWriter("C:\\Users\\halle\\Desktop\\CSCUT4Practical2-main\\CSCUT4Practical2-main\\output.txt"); // writes the text file in a given directory
        //C:\Users\halle\Desktop\CSCUT4Practical2-main\CSCUT4Practical2-main\output.txt

        // Initially it will be easier to hardcode suitable file names.
        // Set up a new Scanner to read the input file.

        char[] Name;
        char[] temp;

        Scanner sc = new Scanner(reader);

        while (sc.hasNextLine())
        {
            Name = sc.nextLine().toCharArray(); //converts String to char array
            Name[0] = Character.toTitleCase(Name[0]); //capitalizes the first character

            /**
             * Creation of a temporary array that is 2 indexes longer than the Name array
             */

            temp = new char[Name.length + 2];
            for(int i = 0; i < Name.length; i++)
            {
                temp[i] = Name[i];
            }

            char[] date = new char[9]; // the date in integers
            int count = 8;

            /**
             * Creates a new temporary array (date) which begins at the end of the date integers
             *
             */
            for(int z = Name.length - 1; z > Name.length - 10; z--)
            {
                date[count] = Name[z];
                count--;

            }
            char[] formattedDate = new char[11];
            count = 0;

            /**
             * Loops through the array and places '/' at the 3rd and 6th indexes
             * else count is incremented to loop through the array and nothing gets added
             */

            for(int y = 0; y < formattedDate.length; y++)
            {

                if(y == 3 || y == 6)
                {
                    formattedDate[y] = '/';
                }
                else
                {
                    formattedDate[y] = date[count];
                    count++;
                }
            }

            /**
             * Capitalizes the first char of the surname, initials and adds a '.' after the initials
             */
            for(int i = 0; i < Name.length; i++)
            {
                 if (Name[i] == ' ') //checks for an empty space
                {
                    temp[i+1] = Character.toTitleCase(Name[i+1]); //sets the next char capitalized

                    if(Name[i+2] == ' ')
                    {
                        for(int j = temp.length - 1; j > i + 1; j--)
                        {
                            temp[j] = temp[j - 1];
                        }

                        temp[i+2] = '.';

                    }
                }
                 Name = temp;

            }


            /**
             * final loop to insert '/' in between the indexes
             * Loops backwards once again
             */
            count = 10;
            for(int i = Name.length - 1; i > Name.length - 11; i--)
            {

                Name[i] = formattedDate[count];
                count--;
            }


            writer.println(Name); //stores the data
            System.out.println(Name); //prints the formatted Name
            System.out.println(" "); //prints an empty line

        }
        writer.close(); //executes the data in a new text file

    }


        // Processing line by line would be sensible here.
        // Initially, echo the text to System.out to check you are reading correctly.
        // Then add code to modify the text to the output format.

        // Set up a new PrintWriter to write the output file.
        // Add suitable code into the above processing (because you need to do this line by line also.
        // That is, read a line, write a line, loop.

        // Finally, add code to read the filenames as arguments from the command line.


    // main


} // FilesInOut
